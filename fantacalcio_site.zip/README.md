# Sito Fantacalcio Community

Questo è il sito della Lega Fantacalcio 2025 gestito da FantaLombardo85.

## Come aggiornare

1. Modifica `index.html` con le nuove classifiche, rose o risultati.
2. Fai commit e push delle modifiche su GitHub.
3. Il sito si aggiornerà automaticamente su GitHub Pages.

## Link del sito

https://fantalombardo85.github.io
